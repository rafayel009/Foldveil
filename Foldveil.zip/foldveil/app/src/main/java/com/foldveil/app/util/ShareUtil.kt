package com.foldveil.app.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object ShareUtil {

    /** Opens the system share sheet for a single image URI — works with any
     * installed app that accepts images (Gmail, WhatsApp, Instagram, etc). */
    fun sharePhoto(context: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share photo"))
    }

    /** Opens the system chooser to edit this photo in another installed app. */
    fun openInEditor(context: Context, uri: Uri) {
        val intent = Intent(Intent.ACTION_EDIT).apply {
            setDataAndType(uri, "image/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        try {
            context.startActivity(Intent.createChooser(intent, "Edit with"))
        } catch (e: Exception) {
            Toast.makeText(context, "No editing app found", Toast.LENGTH_SHORT).show()
        }
    }

    /** Sets the given image as the device wallpaper via the system wallpaper picker. */
    fun setAsWallpaper(context: Context, uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_ATTACH_DATA).apply {
                setDataAndType(uri, "image/*")
                putExtra("mimeType", "image/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Set as wallpaper"))
        } catch (e: Exception) {
            Toast.makeText(context, "Couldn't open wallpaper picker", Toast.LENGTH_SHORT).show()
        }
    }
}
