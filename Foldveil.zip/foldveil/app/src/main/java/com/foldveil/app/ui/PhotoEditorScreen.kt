package com.foldveil.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.RotateLeft
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

private enum class EditTool { ADJUST, ROTATE }

@Composable
fun PhotoEditorScreen(
    uri: Uri,
    onBack: () -> Unit,
    onSaved: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    var brightness by remember { mutableFloatStateOf(0f) } // -100..100
    var contrast by remember { mutableFloatStateOf(0f) }   // -100..100
    var saturation by remember { mutableFloatStateOf(0f) } // -100..100
    var rotationDegrees by remember { mutableIntStateOf(0) }
    var tool by remember { mutableStateOf(EditTool.ADJUST) }

    LaunchedEffect(uri) {
        withContext(Dispatchers.IO) {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                sourceBitmap = BitmapFactory.decodeStream(stream)
            }
        }
    }

    val colorMatrix = remember(brightness, contrast, saturation) {
        buildColorMatrix(brightness, contrast, saturation)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 8.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancel", tint = Color.White)
            }
            Text(
                text = "Edit",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 4.dp)
            )
            Spacer(modifier = Modifier.weight(1f))
            if (isSaving) {
                CircularProgressIndicator(
                    color = Color(0xFF7F77DD),
                    modifier = Modifier
                        .padding(end = 8.dp)
                        .width(20.dp)
                        .height(20.dp),
                    strokeWidth = 2.dp
                )
            } else {
                IconButton(onClick = {
                    val bmp = sourceBitmap
                    if (bmp != null) {
                        isSaving = true
                        scope.launch {
                            val success = withContext(Dispatchers.IO) {
                                saveEditedPhoto(context, bmp, rotationDegrees, brightness, contrast, saturation)
                            }
                            isSaving = false
                            if (success) {
                                Toast.makeText(context, "Saved as a new photo", Toast.LENGTH_SHORT).show()
                                onSaved()
                            } else {
                                Toast.makeText(context, "Couldn't save edit", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }) {
                    Icon(Icons.Filled.Check, contentDescription = "Save", tint = Color(0xFF7F77DD))
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            val bmp = sourceBitmap
            if (bmp == null) {
                CircularProgressIndicator(color = Color(0xFF7F77DD))
            } else {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    colorFilter = ColorFilter.colorMatrix(colorMatrix),
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .rotate(rotationDegrees.toFloat())
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            EditTab(label = "Adjust", selected = tool == EditTool.ADJUST) { tool = EditTool.ADJUST }
            EditTab(label = "Rotate", selected = tool == EditTool.ROTATE) { tool = EditTool.ROTATE }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            when (tool) {
                EditTool.ADJUST -> {
                    AdjustSlider(label = "Brightness", value = brightness, onChange = { brightness = it })
                    AdjustSlider(label = "Contrast", value = contrast, onChange = { contrast = it })
                    AdjustSlider(label = "Saturation", value = saturation, onChange = { saturation = it })
                }
                EditTool.ROTATE -> {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { rotationDegrees = (rotationDegrees - 90 + 360) % 360 }) {
                            Icon(Icons.Filled.RotateLeft, contentDescription = "Rotate left", tint = Color.White)
                        }
                        Text(
                            text = "$rotationDegrees\u00b0",
                            color = Color.White,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        IconButton(onClick = { rotationDegrees = (rotationDegrees + 90) % 360 }) {
                            Icon(Icons.Filled.RotateRight, contentDescription = "Rotate right", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditTab(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = label,
        color = if (selected) Color.White else Color.White.copy(alpha = 0.5f),
        fontSize = 14.sp,
        fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal,
        modifier = Modifier
            .padding(vertical = 8.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
    )
}

@Composable
private fun AdjustSlider(label: String, value: Float, onChange: (Float) -> Unit) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(text = label, color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = -100f..100f,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF7F77DD),
                activeTrackColor = Color(0xFF7F77DD),
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )
    }
}

/** Builds a ColorMatrix combining brightness, contrast, and saturation adjustments. */
private fun buildColorMatrix(brightness: Float, contrast: Float, saturation: Float): ColorMatrix {
    val b = brightness * 2.55f // -255..255
    val c = (contrast + 100f) / 100f // 0..2
    val s = (saturation + 100f) / 100f // 0..2

    val contrastTranslate = (1 - c) * 128f

    val contrastMatrix = ColorMatrix(
        floatArrayOf(
            c, 0f, 0f, 0f, contrastTranslate + b,
            0f, c, 0f, 0f, contrastTranslate + b,
            0f, 0f, c, 0f, contrastTranslate + b,
            0f, 0f, 0f, 1f, 0f
        )
    )

    val saturationMatrix = ColorMatrix().apply { setToSaturation(s) }

    return contrastMatrix.also { it.timesAssign(saturationMatrix) }
}

private suspend fun saveEditedPhoto(
    context: android.content.Context,
    original: Bitmap,
    rotationDegrees: Int,
    brightness: Float,
    contrast: Float,
    saturation: Float
): Boolean {
    return try {
        var bmp = original
        if (rotationDegrees != 0) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
        }

        val paint = android.graphics.Paint()
        val cm = buildColorMatrix(brightness, contrast, saturation)
        val androidMatrix = android.graphics.ColorMatrix(cm.values)
        paint.colorFilter = android.graphics.ColorMatrixColorFilter(androidMatrix)

        val output = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(output)
        canvas.drawBitmap(bmp, 0f, 0f, paint)

        val filename = "Foldveil_edit_${System.currentTimeMillis()}.jpg"
        val values = android.content.ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Foldveil")
        }

        val resolver = context.contentResolver
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val itemUri = resolver.insert(collection, values) ?: return false

        var outputStream: OutputStream? = null
        try {
            outputStream = resolver.openOutputStream(itemUri)
            if (outputStream != null) {
                output.compress(Bitmap.CompressFormat.JPEG, 92, outputStream)
            }
        } finally {
            outputStream?.close()
        }

        true
    } catch (e: Exception) {
        false
    }
}
