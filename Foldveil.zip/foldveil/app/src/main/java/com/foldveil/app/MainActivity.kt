package com.foldveil.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.foldveil.app.ui.FoldveilApp
import com.foldveil.app.ui.theme.FoldveilTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FoldveilTheme {
                FoldveilApp()
            }
        }
    }
}
