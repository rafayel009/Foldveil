package com.foldveil.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.foldveil.app.ui.FoldveilGalleryScreen
import com.foldveil.app.ui.theme.FoldveilTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FoldveilTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    FoldveilGalleryScreen()
                }
            }
        }
    }
}
