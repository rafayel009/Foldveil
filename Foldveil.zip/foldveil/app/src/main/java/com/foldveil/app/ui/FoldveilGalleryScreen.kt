package com.foldveil.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

// Matches the preview: cover starts fully opaque, eases out, ends mostly translucent.
private val VeilEasing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)
private const val VEIL_DURATION_MS = 520
private const val MAX_SWEEP_DEGREES = 100f
private const val MIN_OPACITY_AT_END = 0.15f

@Composable
fun FoldveilGalleryScreen() {
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var nextIndex by remember { mutableStateOf<Int?>(null) }
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var isAnimating by remember { mutableStateOf(false) }

    val pickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris ->
        if (uris.isNotEmpty()) {
            photos = uris
            currentIndex = 0
            nextIndex = null
        }
    }

    fun launchPicker() {
        pickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
    }

    fun goTo(index: Int) {
        if (isAnimating || photos.isEmpty()) return
        val target = ((index % photos.size) + photos.size) % photos.size
        if (target == currentIndex) return
        isAnimating = true
        nextIndex = target
        scope.launch {
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = VEIL_DURATION_MS, easing = VeilEasing)
            )
            currentIndex = target
            nextIndex = null
            progress.snapTo(0f)
            isAnimating = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Foldveil",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium
            )
            Button(
                onClick = { launchPicker() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3C3489))
            ) {
                Text(if (photos.isEmpty()) "Choose photos" else "Change photos")
            }
        }

        Box(
            modifier = Modifier
                .padding(top = 20.dp)
                .fillMaxWidth()
                .aspectRatio(9f / 16f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1A1A1F))
                .then(
                    if (photos.isNotEmpty()) {
                        Modifier.pointerInput(currentIndex, photos) {
                            var totalDrag = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalDrag = 0f },
                                onDragEnd = {
                                    if (totalDrag.absoluteValue > 60f) {
                                        if (totalDrag < 0) goTo(currentIndex + 1) else goTo(currentIndex - 1)
                                    }
                                }
                            ) { change, dragAmount ->
                                change.consume()
                                totalDrag += dragAmount
                            }
                        }
                    } else {
                        Modifier
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (photos.isEmpty()) {
                EmptyState(onPick = { launchPicker() })
            } else {
                // Underneath layer: the photo being revealed
                val revealUri = photos[nextIndex ?: currentIndex]
                PhotoContent(uri = revealUri, modifier = Modifier.fillMaxSize())

                // Cover layer: the current photo, swinging open like a book cover
                val coverUri = photos[currentIndex]
                val sweepAngle = progress.value * MAX_SWEEP_DEGREES
                val coverOpacity = 1f - (progress.value * (1f - MIN_OPACITY_AT_END))

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            // Hinge on the right edge, sweeping left, like opening a book cover.
                            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 0.5f)
                            rotationY = -sweepAngle
                            cameraDistance = 24f * density
                            alpha = coverOpacity
                        }
                ) {
                    PhotoContent(uri = coverUri, modifier = Modifier.fillMaxSize())
                }

                // Tap zones: left third goes back, right third advances
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(1f / 3f)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { goTo(currentIndex - 1) }
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.5f)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(1f)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { goTo(currentIndex + 1) }
                    )
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(14.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = 0.35f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${currentIndex + 1} / ${photos.size}",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
            }
        }

        if (photos.isNotEmpty()) {
            Row(
                modifier = Modifier.padding(top = 14.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                photos.indices.forEach { i ->
                    Dot(active = i == currentIndex)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(onPick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "No photos selected",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 14.sp
        )
        Box(modifier = Modifier.padding(top = 12.dp)) {
            Button(
                onClick = onPick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3C3489))
            ) {
                Text("Pick photos from your gallery")
            }
        }
    }
}

@Composable
private fun Dot(active: Boolean) {
    Box(
        modifier = Modifier
            .padding(horizontal = 3.dp)
            .size(width = if (active) 16.dp else 6.dp, height = 6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(if (active) Color(0xFF7F77DD) else Color.White.copy(alpha = 0.25f))
    )
}

@Composable
private fun PhotoContent(uri: Uri, modifier: Modifier = Modifier) {
    Image(
        painter = rememberAsyncImagePainter(model = uri),
        contentDescription = null,
        modifier = modifier,
        contentScale = ContentScale.Crop
    )
}
