package com.foldveil.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "foldveil_prefs")

private val FAVORITES_KEY = stringSetPreferencesKey("favorite_uris")
private val TRASH_KEY = stringSetPreferencesKey("trashed_uris")

/**
 * Tracks favorites and trash as sets of photo URI strings, persisted locally.
 * Trash here is app-level only (hides photos from view) — it does not touch
 * the underlying MediaStore file, so nothing is destructively deleted until
 * the user explicitly empties the trash.
 */
class UserStateRepository(private val context: Context) {

    val favoriteUris: Flow<Set<String>> =
        context.dataStore.data.map { prefs -> prefs[FAVORITES_KEY] ?: emptySet() }

    val trashedUris: Flow<Set<String>> =
        context.dataStore.data.map { prefs -> prefs[TRASH_KEY] ?: emptySet() }

    suspend fun toggleFavorite(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[FAVORITES_KEY] ?: emptySet()
            prefs[FAVORITES_KEY] = if (uri in current) current - uri else current + uri
        }
    }

    suspend fun moveToTrash(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[TRASH_KEY] ?: emptySet()
            prefs[TRASH_KEY] = current + uri
        }
    }

    suspend fun moveManyToTrash(uris: Collection<String>) {
        context.dataStore.edit { prefs ->
            val current = prefs[TRASH_KEY] ?: emptySet()
            prefs[TRASH_KEY] = current + uris
        }
    }

    suspend fun restoreFromTrash(uri: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[TRASH_KEY] ?: emptySet()
            prefs[TRASH_KEY] = current - uri
        }
    }

    suspend fun removeFromTrashRecord(uri: String) {
        // Called after the underlying file has actually been deleted permanently,
        // so the trash record doesn't keep a dangling reference.
        context.dataStore.edit { prefs ->
            val trash = prefs[TRASH_KEY] ?: emptySet()
            val favs = prefs[FAVORITES_KEY] ?: emptySet()
            prefs[TRASH_KEY] = trash - uri
            prefs[FAVORITES_KEY] = favs - uri
        }
    }
}
