package com.foldveil.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.foldveil.app.data.Photo
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

// Cover starts fully opaque, eases out, ends mostly translucent — like a book cover lifting open.
private val VeilEasing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)
private const val VEIL_DURATION_MS = 520
private const val MAX_SWEEP_DEGREES = 100f
private const val MIN_OPACITY_AT_END = 0.15f

@Composable
fun PhotoViewerScreen(
    photos: List<Photo>,
    startIndex: Int,
    onBack: () -> Unit
) {
    var currentIndex by remember { mutableIntStateOf(startIndex) }
    var nextIndex by remember { mutableStateOf<Int?>(null) }
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var isAnimating by remember { mutableStateOf(false) }

    fun goTo(index: Int) {
        if (isAnimating || photos.isEmpty()) return
        val target = ((index % photos.size) + photos.size) % photos.size
        if (target == currentIndex) return
        isAnimating = true
        nextIndex = target
        scope.launch {
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = VEIL_DURATION_MS, easing = VeilEasing)
            )
            currentIndex = target
            nextIndex = null
            progress.snapTo(0f)
            isAnimating = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (photos.isNotEmpty()) {
            val revealPhoto = photos[nextIndex ?: currentIndex]
            Image(
                painter = rememberAsyncImagePainter(model = revealPhoto.uri),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Fit
            )

            val coverPhoto = photos[currentIndex]
            val sweepAngle = progress.value * MAX_SWEEP_DEGREES
            val coverOpacity = 1f - (progress.value * (1f - MIN_OPACITY_AT_END))

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        transformOrigin = TransformOrigin(1f, 0.5f)
                        rotationY = -sweepAngle
                        cameraDistance = 24f * density
                        alpha = coverOpacity
                    }
            ) {
                Image(
                    painter = rememberAsyncImagePainter(model = coverPhoto.uri),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(currentIndex, photos) {
                        var totalDrag = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { totalDrag = 0f },
                            onDragEnd = {
                                if (totalDrag.absoluteValue > 60f) {
                                    if (totalDrag < 0) goTo(currentIndex + 1) else goTo(currentIndex - 1)
                                }
                            }
                        ) { change, dragAmount ->
                            change.consume()
                            totalDrag += dragAmount
                        }
                    }
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(1f / 3f)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { goTo(currentIndex - 1) }
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(0.5f)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(1f)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { goTo(currentIndex + 1) }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(14.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${currentIndex + 1} / ${photos.size}",
                    color = Color.White,
                    fontSize = 12.sp
                )
            }
        }

        IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = Color.White
            )
        }
    }
}
