package com.foldveil.app.ui

import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.foldveil.app.data.Photo
import com.foldveil.app.util.ShareUtil
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue
import kotlin.math.max

// Cover starts fully opaque, eases out, ends mostly translucent — like a book cover lifting open.
// Direction-aware: swiping left opens right-to-left, swiping right opens left-to-right.
private val VeilEasing = CubicBezierEasing(0.4f, 0f, 0.2f, 1f)
private const val VEIL_DURATION_MS = 480
private const val MAX_SWEEP_DEGREES = 100f
private const val MIN_OPACITY_AT_END = 0.15f
private const val MAX_BLUR_DP = 18f

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoViewerScreen(
    photos: List<Photo>,
    startIndex: Int,
    isFavorite: (Photo) -> Boolean,
    onBack: () -> Unit,
    onToggleFavorite: (Photo) -> Unit,
    onMoveToTrash: (Photo) -> Unit,
    onEdit: (Photo) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var currentIndex by remember { mutableIntStateOf(startIndex) }
    var nextIndex by remember { mutableStateOf<Int?>(null) }
    var direction by remember { mutableIntStateOf(1) } // 1 = forward (swipe left), -1 = backward (swipe right)
    val progress = remember { Animatable(0f) }
    var isAnimating by remember { mutableStateOf(false) }

    var showMenu by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }
    val detailsSheetState = rememberModalBottomSheetState()

    // Pinch-zoom state, reset whenever the current photo changes
    var scale by remember(currentIndex) { mutableFloatStateOf(1f) }
    var offsetX by remember(currentIndex) { mutableFloatStateOf(0f) }
    var offsetY by remember(currentIndex) { mutableFloatStateOf(0f) }

    fun goTo(index: Int, swipeDirection: Int) {
        if (isAnimating || photos.isEmpty() || scale > 1.05f) return
        val target = ((index % photos.size) + photos.size) % photos.size
        if (target == currentIndex) return
        isAnimating = true
        direction = swipeDirection
        nextIndex = target
        scope.launch {
            progress.snapTo(0f)
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = VEIL_DURATION_MS, easing = VeilEasing)
            )
            currentIndex = target
            nextIndex = null
            progress.snapTo(0f)
            isAnimating = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (photos.isNotEmpty()) {
            val incomingPhoto = photos[nextIndex ?: currentIndex]
            val outgoingPhoto = photos[currentIndex]
            val p = progress.value
            val forward = direction >= 0

            // Incoming photo: slides in from the swipe direction, blur descends to sharp.
            val incomingOffsetFraction = if (nextIndex != null) (1f - p) else 0f
            val incomingTranslate = if (forward) incomingOffsetFraction else -incomingOffsetFraction
            val incomingBlur = if (nextIndex != null) MAX_BLUR_DP * (1f - p) else 0f

            BlurredImage(
                uri = incomingPhoto.uri,
                blurDp = incomingBlur,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationX = incomingTranslate * size.width
                    }
            )

            // Outgoing (cover) photo: book-cover sweep, hinge follows swipe direction,
            // also slides out and blurs ascending as it leaves.
            if (nextIndex != null) {
                val sweepAngle = p * MAX_SWEEP_DEGREES
                val coverOpacity = 1f - (p * (1f - MIN_OPACITY_AT_END))
                val outgoingTranslate = if (forward) -p else p
                val outgoingBlur = MAX_BLUR_DP * p

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            transformOrigin = TransformOrigin(if (forward) 1f else 0f, 0.5f)
                            rotationY = if (forward) -sweepAngle else sweepAngle
                            cameraDistance = 24f * density
                            alpha = coverOpacity
                            translationX = outgoingTranslate * size.width * 0.15f
                        }
                ) {
                    BlurredImage(
                        uri = outgoingPhoto.uri,
                        blurDp = outgoingBlur,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // Zoomable / pannable / swipeable gesture layer
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(currentIndex, photos) {
                        var totalDrag = 0f
                        detectHorizontalDragGestures(
                            onDragStart = { totalDrag = 0f },
                            onDragEnd = {
                                if (scale <= 1.05f && totalDrag.absoluteValue > 60f) {
                                    if (totalDrag < 0) {
                                        goTo(currentIndex + 1, swipeDirection = 1)
                                    } else {
                                        goTo(currentIndex - 1, swipeDirection = -1)
                                    }
                                }
                            }
                        ) { change, dragAmount ->
                            if (scale > 1.05f) {
                                change.consume()
                                offsetX += dragAmount
                            } else {
                                change.consume()
                                totalDrag += dragAmount
                            }
                        }
                    }
                    .pointerInput(currentIndex) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            if (scale > 1f) {
                                offsetX += pan.x
                                offsetY += pan.y
                            } else {
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    }
            )

            if (scale > 1.01f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offsetX
                            translationY = offsetY
                        }
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(model = outgoingPhoto.uri),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }

            // Top bar: back, counter, overflow menu
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .padding(4.dp)
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = 0.45f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${currentIndex + 1} / ${photos.size}",
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.weight(1f))

                val favored = isFavorite(outgoingPhoto)
                IconButton(onClick = { onToggleFavorite(outgoingPhoto) }) {
                    Icon(
                        imageVector = if (favored) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (favored) Color(0xFFD4537E) else Color.White
                    )
                }
                IconButton(onClick = { ShareUtil.sharePhoto(context, outgoingPhoto.uri) }) {
                    Icon(Icons.Filled.Share, contentDescription = "Share", tint = Color.White)
                }
                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = Color.White)
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Edit") },
                            leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                            onClick = { showMenu = false; onEdit(outgoingPhoto) }
                        )
                        DropdownMenuItem(
                            text = { Text("Edit with\u2026") },
                            leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                            onClick = { showMenu = false; ShareUtil.openInEditor(context, outgoingPhoto.uri) }
                        )
                        DropdownMenuItem(
                            text = { Text("Set as wallpaper") },
                            leadingIcon = { Icon(Icons.Filled.Wallpaper, contentDescription = null) },
                            onClick = { showMenu = false; ShareUtil.setAsWallpaper(context, outgoingPhoto.uri) }
                        )
                        DropdownMenuItem(
                            text = { Text("Details") },
                            leadingIcon = { Icon(Icons.Filled.Info, contentDescription = null) },
                            onClick = { showMenu = false; showDetails = true }
                        )
                        DropdownMenuItem(
                            text = { Text("Move to trash") },
                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onMoveToTrash(outgoingPhoto)
                                onBack()
                            }
                        )
                    }
                }
            }

            if (showDetails) {
                PhotoDetailsSheet(
                    photo = outgoingPhoto,
                    sheetState = detailsSheetState,
                    onDismiss = { showDetails = false }
                )
            }
        }
    }
}

/** Renders an image with an optional blur applied via RenderEffect (API 31+).
 * On older API levels the blur amount is ignored gracefully (image just renders sharp). */
@Composable
private fun BlurredImage(uri: Uri, blurDp: Float, modifier: Modifier = Modifier) {
    val density = LocalDensity.current

    Image(
        painter = rememberAsyncImagePainter(model = uri),
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = modifier.graphicsLayer {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && blurDp > 0.5f) {
                val radiusPx = max(0.1f, blurDp * density.density)
                renderEffect = RenderEffect
                    .createBlurEffect(radiusPx, radiusPx, Shader.TileMode.CLAMP)
                    .asComposeRenderEffect()
            } else {
                renderEffect = null
            }
        }
    )
}
