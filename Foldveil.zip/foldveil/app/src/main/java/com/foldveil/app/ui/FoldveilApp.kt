package com.foldveil.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.foldveil.app.data.Album
import com.foldveil.app.data.MediaStoreRepository
import com.foldveil.app.data.Photo

private sealed interface Screen {
    data object Albums : Screen
    data class PhotoGrid(val album: Album) : Screen
    data class Viewer(val album: Album, val startIndex: Int) : Screen
}

private fun readImagesPermission(): String =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_IMAGES
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

@Composable
fun FoldveilApp() {
    val context = LocalContext.current
    val permission = remember { readImagesPermission() }

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, permission) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var permanentlyDenied by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (!granted) {
            permanentlyDenied = true
        }
    }

    var allPhotos by remember { mutableStateOf<List<Photo>>(emptyList()) }
    var albums by remember { mutableStateOf<List<Album>>(emptyList()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Albums) }

    LaunchedEffect(hasPermission) {
        if (hasPermission) {
            val photos = MediaStoreRepository.queryAllPhotos(context)
            allPhotos = photos
            albums = MediaStoreRepository.groupIntoAlbums(photos)
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        if (!hasPermission) {
            PermissionScreen(
                permanentlyDenied = permanentlyDenied,
                onRequestPermission = { permissionLauncher.launch(permission) },
                onOpenSettings = {
                    val intent = android.content.Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.fromParts("package", context.packageName, null)
                    )
                    context.startActivity(intent)
                }
            )
        } else {
            when (val current = screen) {
                is Screen.Albums -> {
                    AlbumGridScreen(
                        albums = albums,
                        onAlbumClick = { album -> screen = Screen.PhotoGrid(album) }
                    )
                }

                is Screen.PhotoGrid -> {
                    val photosInAlbum = allPhotos.filter { it.bucketId == current.album.bucketId }
                    PhotoGridScreen(
                        albumName = current.album.bucketName,
                        photos = photosInAlbum,
                        onBack = { screen = Screen.Albums },
                        onPhotoClick = { index -> screen = Screen.Viewer(current.album, index) }
                    )
                }

                is Screen.Viewer -> {
                    val photosInAlbum = allPhotos.filter { it.bucketId == current.album.bucketId }
                    PhotoViewerScreen(
                        photos = photosInAlbum,
                        startIndex = current.startIndex,
                        onBack = { screen = Screen.PhotoGrid(current.album) }
                    )
                }
            }
        }
    }
}
