package com.foldveil.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.foldveil.app.data.Album
import com.foldveil.app.data.MediaStoreRepository
import com.foldveil.app.data.Photo
import com.foldveil.app.data.UserStateRepository
import kotlinx.coroutines.launch

private sealed interface Screen {
    data object Albums : Screen
    data object AllPhotos : Screen
    data object Favorites : Screen
    data object Trash : Screen
    data class PhotoGrid(val album: Album) : Screen
    data class Viewer(val photos: List<Photo>, val startIndex: Int, val back: Screen) : Screen
    data class Editor(val photo: Photo, val back: Screen) : Screen
}

private fun readImagesPermission(): String =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_IMAGES
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

@Composable
fun FoldveilApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val permission = remember { readImagesPermission() }
    val userState = remember { UserStateRepository(context) }

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, permission) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var permanentlyDenied by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (!granted) permanentlyDenied = true
    }

    var allPhotos by remember { mutableStateOf<List<Photo>>(emptyList()) }
    var albums by remember { mutableStateOf<List<Album>>(emptyList()) }
    var screen by remember { mutableStateOf<Screen>(Screen.Albums) }
    var refreshTrigger by remember { mutableStateOf(0) }

    val favoriteUris by userState.favoriteUris.collectAsState(initial = emptySet())
    val trashedUris by userState.trashedUris.collectAsState(initial = emptySet())

    LaunchedEffect(hasPermission, refreshTrigger) {
        if (hasPermission) {
            val photos = MediaStoreRepository.queryAllPhotos(context)
            allPhotos = photos
        }
    }

    LaunchedEffect(allPhotos, trashedUris) {
        albums = MediaStoreRepository.groupIntoAlbums(
            allPhotos.filter { it.uri.toString() !in trashedUris }
        )
    }

    fun visiblePhotos(source: List<Photo>): List<Photo> =
        source.filter { it.uri.toString() !in trashedUris }

    fun isFavorite(photo: Photo): Boolean = photo.uri.toString() in favoriteUris

    fun toggleFavorite(photo: Photo) {
        scope.launch { userState.toggleFavorite(photo.uri.toString()) }
    }

    fun moveToTrash(photo: Photo) {
        scope.launch { userState.moveToTrash(photo.uri.toString()) }
    }

    fun restoreFromTrash(photo: Photo) {
        scope.launch { userState.restoreFromTrash(photo.uri.toString()) }
    }

    fun deleteForever(photo: Photo) {
        scope.launch {
            val ok = MediaStoreRepository.deletePermanently(context, photo.uri)
            if (ok) {
                userState.removeFromTrashRecord(photo.uri.toString())
                refreshTrigger++
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        if (!hasPermission) {
            PermissionScreen(
                permanentlyDenied = permanentlyDenied,
                onRequestPermission = { permissionLauncher.launch(permission) },
                onOpenSettings = {
                    val intent = android.content.Intent(
                        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.fromParts("package", context.packageName, null)
                    )
                    context.startActivity(intent)
                }
            )
        } else {
            when (val current = screen) {
                is Screen.Albums -> {
                    AlbumGridScreen(
                        albums = albums,
                        onAlbumClick = { album -> screen = Screen.PhotoGrid(album) },
                        onOpenAllPhotos = { screen = Screen.AllPhotos },
                        onOpenFavorites = { screen = Screen.Favorites },
                        onOpenTrash = { screen = Screen.Trash }
                    )
                }

                is Screen.AllPhotos -> {
                    val visible = visiblePhotos(allPhotos)
                    val sorted = remember(visible) { visible.sortedBy { it.name.lowercase() } }
                    AllPhotosScreen(
                        photos = sorted,
                        onBack = { screen = Screen.Albums },
                        onPhotoClick = { index ->
                            screen = Screen.Viewer(sorted, index, Screen.AllPhotos)
                        }
                    )
                }

                is Screen.Favorites -> {
                    val favPhotos = visiblePhotos(allPhotos).filter { isFavorite(it) }
                    FavoritesScreen(
                        favoritePhotos = favPhotos,
                        onBack = { screen = Screen.Albums },
                        onPhotoClick = { index ->
                            screen = Screen.Viewer(favPhotos, index, Screen.Favorites)
                        }
                    )
                }

                is Screen.Trash -> {
                    val trashedPhotos = allPhotos.filter { it.uri.toString() in trashedUris }
                    TrashScreen(
                        trashedPhotos = trashedPhotos,
                        onBack = { screen = Screen.Albums },
                        onRestore = { photo -> restoreFromTrash(photo) },
                        onDeleteForever = { photo -> deleteForever(photo) }
                    )
                }

                is Screen.PhotoGrid -> {
                    val photosInAlbum = visiblePhotos(allPhotos).filter { it.bucketId == current.album.bucketId }
                    PhotoGridScreen(
                        albumName = current.album.bucketName,
                        photos = photosInAlbum,
                        onBack = { screen = Screen.Albums },
                        onPhotoClick = { index ->
                            screen = Screen.Viewer(photosInAlbum, index, current)
                        }
                    )
                }

                is Screen.Viewer -> {
                    PhotoViewerScreen(
                        photos = current.photos,
                        startIndex = current.startIndex,
                        isFavorite = { photo -> isFavorite(photo) },
                        onBack = { screen = current.back },
                        onToggleFavorite = { photo -> toggleFavorite(photo) },
                        onMoveToTrash = { photo -> moveToTrash(photo) },
                        onEdit = { photo -> screen = Screen.Editor(photo, current) }
                    )
                }

                is Screen.Editor -> {
                    PhotoEditorScreen(
                        uri = current.photo.uri,
                        onBack = { screen = current.back },
                        onSaved = {
                            refreshTrigger++
                            screen = current.back
                        }
                    )
                }
            }
        }
    }
}
