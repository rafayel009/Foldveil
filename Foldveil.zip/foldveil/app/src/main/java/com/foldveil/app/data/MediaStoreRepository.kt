package com.foldveil.app.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Photo(
    val uri: Uri,
    val name: String,
    val dateAdded: Long,
    val bucketId: String,
    val bucketName: String
)

data class Album(
    val bucketId: String,
    val bucketName: String,
    val coverUri: Uri,
    val photoCount: Int
)

object MediaStoreRepository {

    /**
     * Queries all images visible to the app via MediaStore and returns them
     * newest-first. Requires READ_MEDIA_IMAGES (API 33+) or
     * READ_EXTERNAL_STORAGE (below API 33) to already be granted.
     */
    fun queryAllPhotos(context: Context): List<Photo> {
        val photos = mutableListOf<Photo>()

        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"

        context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            val bucketIdCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val bucketNameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val uri = ContentUris.withAppendedId(collection, id)
                photos.add(
                    Photo(
                        uri = uri,
                        name = cursor.getString(nameCol) ?: "",
                        dateAdded = cursor.getLong(dateCol),
                        bucketId = cursor.getString(bucketIdCol) ?: "unknown",
                        bucketName = cursor.getString(bucketNameCol) ?: "Unknown"
                    )
                )
            }
        }

        return photos
    }

    /** Groups a flat photo list into albums (folders), largest-first. */
    fun groupIntoAlbums(photos: List<Photo>): List<Album> {
        return photos
            .groupBy { it.bucketId }
            .map { (bucketId, photosInBucket) ->
                val sorted = photosInBucket.sortedByDescending { it.dateAdded }
                Album(
                    bucketId = bucketId,
                    bucketName = sorted.first().bucketName,
                    coverUri = sorted.first().uri,
                    photoCount = sorted.size
                )
            }
            .sortedByDescending { it.photoCount }
    }
}
