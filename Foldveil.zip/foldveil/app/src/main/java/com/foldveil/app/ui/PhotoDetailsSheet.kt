package com.foldveil.app.ui

import android.text.format.DateUtils
import android.text.format.Formatter
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.foldveil.app.data.Photo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhotoDetailsSheet(
    photo: Photo,
    sheetState: SheetState,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF17171C)
    ) {
        Column(modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text(
                text = "Details",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            DetailRow(label = "Name", value = photo.name)
            DetailRow(label = "Folder", value = photo.bucketName)
            DetailRow(
                label = "Date added",
                value = DateUtils.formatDateTime(
                    context,
                    photo.dateAdded * 1000L,
                    DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_TIME or DateUtils.FORMAT_SHOW_YEAR
                )
            )
            DetailRow(
                label = "Dimensions",
                value = if (photo.width > 0 && photo.height > 0) {
                    "${photo.width} \u00d7 ${photo.height}"
                } else {
                    "Unknown"
                }
            )
            DetailRow(
                label = "File size",
                value = if (photo.sizeBytes > 0) {
                    Formatter.formatShortFileSize(context, photo.sizeBytes)
                } else {
                    "Unknown"
                }
            )

            Spacer(modifier = Modifier.padding(bottom = 24.dp))
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            text = label,
            color = Color.White.copy(alpha = 0.5f),
            fontSize = 12.sp
        )
        Text(
            text = value,
            color = Color.White,
            fontSize = 15.sp,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}
