# Foldveil

A minimal, functional photo gallery app for Android — browse every
photo on your device organized by folder, like a lightweight Google
Photos — with a book-cover reveal transition when viewing photos full
screen, inspired by the iPhone Duo's fold-open animation: the current
photo acts as a translucent cover that sweeps open from the right edge,
starting fully opaque and easing to translucent as it reveals the next
photo underneath.

Built with Kotlin + Jetpack Compose. Minimum Android 8.0 (API 26),
compatible with the Sony Xperia 1 III (Android 11+).

## What's inside

- `MainActivity.kt` — app entry point
- `ui/FoldveilApp.kt` — permission handling and screen navigation
- `ui/PermissionScreen.kt` — shown until storage access is granted
- `ui/AlbumGridScreen.kt` — folder grid (every album on the device,
  largest first)
- `ui/PhotoGridScreen.kt` — thumbnail grid within a chosen folder
- `ui/PhotoViewerScreen.kt` — full-screen photo viewer with the
  fold-veil transition
- `data/MediaStoreRepository.kt` — queries Android's MediaStore for
  every image on the device and groups them into folders
- `ui/theme/Theme.kt` — dark theme, purple accent
- Adaptive app icon: a book seen from above, translucent veil overlay

## How it works

Foldveil reads photos directly from the device's MediaStore, the same
index Google Photos and other gallery apps use — no need to pick files
one at a time. On first launch it asks for photo/storage permission;
once granted, it scans every image on the device and groups them by
folder automatically (Camera, Screenshots, Downloads, WhatsApp Images,
etc. — whatever folders actually exist on your phone).

1. **Album grid** — every folder with photos, cover thumbnail + count
2. Tap a folder → **photo grid** — every photo in that folder
3. Tap a photo → **full-screen viewer** — swipe or tap the edges to
   move between photos in that folder, each transition playing the
   book-cover reveal

## Permissions

Foldveil requests:
- `READ_MEDIA_IMAGES` on Android 13+ (API 33+)
- `READ_EXTERNAL_STORAGE` on Android 12 and below

If you deny it once, the app shows a retry button. If you deny it
permanently ("don't ask again"), it offers a button straight to the
app's system settings page so you can grant it manually.

## Building it

You'll need [Android Studio](https://developer.android.com/studio)
(Giraffe or newer) with Android SDK 34 installed.

1. Open this folder in Android Studio (`File > Open`, select the
   `foldveil` folder).
2. Let Gradle sync — it will download the Gradle 8.7 wrapper and
   dependencies automatically.
3. Connect your Xperia 1 III over USB with USB debugging enabled
   (`Settings > About phone > tap Build number 7 times`, then
   `Settings > System > Developer options > USB debugging`), or use
   an emulator.
4. Click Run (▶) and select your device.

Alternatively, from a terminal with the Android SDK and `ANDROID_HOME`
set:

```
./gradlew installDebug
```

Or build via GitHub Actions with no local Android SDK required — unzip
this project into a repo, add a workflow that runs
`gradle assembleDebug`, and download the built APK from the workflow's
artifacts.

## Tuning the transition

At the top of `PhotoViewerScreen.kt`:

- `VEIL_DURATION_MS` — how long the sweep takes (ms)
- `MAX_SWEEP_DEGREES` — how far the cover rotates open
- `MIN_OPACITY_AT_END` — how translucent the cover gets by the end
  of the sweep (lower = more see-through)
- `VeilEasing` — the easing curve (currently eases out, matching
  "heavy start, light finish")


