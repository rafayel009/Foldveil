# Foldveil

A photo gallery app for Android with a book-cover reveal transition,
inspired by the iPhone Duo's fold-open animation: the current photo acts
as a translucent cover that sweeps open from the right edge (like turning
a book's cover), starting fully opaque and easing to translucent as it
reveals the next photo underneath.

Built with Kotlin + Jetpack Compose. Minimum Android 8.0 (API 26),
compatible with the Sony Xperia 1 III (Android 11+).

## What's inside

- `MainActivity.kt` — app entry point
- `ui/FoldveilGalleryScreen.kt` — the gallery screen and the fold-veil
  transition logic (tap the left/right edges or swipe to navigate)
- `ui/theme/Theme.kt` — dark theme, purple accent
- Adaptive app icon: a book seen from above, translucent veil overlay
- 5 placeholder gradient "photos" — swap in real images, see below

## Building it

You'll need [Android Studio](https://developer.android.com/studio)
(Giraffe or newer) with Android SDK 34 installed.

1. Open this folder in Android Studio (`File > Open`, select the
   `foldveil` folder).
2. Let Gradle sync — it will download the Gradle 8.7 wrapper and
   dependencies automatically.
3. Connect your Xperia 1 III over USB with USB debugging enabled
   (`Settings > About phone > tap Build number 7 times`, then
   `Settings > System > Developer options > USB debugging`), or use
   an emulator.
4. Click Run (▶) and select your device.

Alternatively, from a terminal with the Android SDK and `ANDROID_HOME`
set:

```
./gradlew installDebug
```

## Swapping in real photos

Right now each "photo" is a colored gradient placeholder (see the
`photos` list at the top of `FoldveilGalleryScreen.kt`). To use real
images:

1. Drop image files into `app/src/main/res/drawable/`.
2. Replace `PhotoContent` in `FoldveilGalleryScreen.kt` with an
   `Image(painter = painterResource(id = R.drawable.your_photo), ...)`,
   or load from the device gallery using the Photo Picker API
   (`androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia`)
   if you want the user to choose their own photos at runtime.

## Tuning the transition

At the top of `FoldveilGalleryScreen.kt`:

- `VEIL_DURATION_MS` — how long the sweep takes (ms)
- `MAX_SWEEP_DEGREES` — how far the cover rotates open
- `MIN_OPACITY_AT_END` — how translucent the cover gets by the end
  of the sweep (lower = more see-through)
- `VeilEasing` — the easing curve (currently eases out, matching
  "heavy start, light finish")
