# Foldveil

A photo gallery app for Android with a book-cover reveal transition,
inspired by the iPhone Duo's fold-open animation: the current photo acts
as a translucent cover that sweeps open from the right edge (like turning
a book's cover), starting fully opaque and easing to translucent as it
reveals the next photo underneath.

Built with Kotlin + Jetpack Compose. Minimum Android 8.0 (API 26),
compatible with the Sony Xperia 1 III (Android 11+).

## What's inside

- `MainActivity.kt` — app entry point
- `ui/FoldveilGalleryScreen.kt` — the gallery screen and the fold-veil
  transition logic
- `ui/theme/Theme.kt` — dark theme, purple accent
- Adaptive app icon: a book seen from above, translucent veil overlay
- Uses Android's system **Photo Picker** to let you choose real photos
  from your device — no storage permission required, since the Photo
  Picker runs as a separate secure system UI and only hands the app the
  URIs of images you actually select

## Using the app

1. Tap **Choose photos** (top right) — this opens Android's built-in
   photo picker
2. Select as many photos as you like, tap done
3. Swipe or tap the left/right edges of the photo to move between them
   — each transition plays the book-cover reveal
4. Tap **Change photos** any time to pick a different set

## Building it

You'll need [Android Studio](https://developer.android.com/studio)
(Giraffe or newer) with Android SDK 34 installed.

1. Open this folder in Android Studio (`File > Open`, select the
   `foldveil` folder).
2. Let Gradle sync — it will download the Gradle 8.7 wrapper and
   dependencies automatically.
3. Connect your Xperia 1 III over USB with USB debugging enabled
   (`Settings > About phone > tap Build number 7 times`, then
   `Settings > System > Developer options > USB debugging`), or use
   an emulator.
4. Click Run (▶) and select your device.

Alternatively, from a terminal with the Android SDK and `ANDROID_HOME`
set:

```
./gradlew installDebug
```

Or build via GitHub Actions (see `.github/workflows/build.yml` if
present in your setup) — no local Android SDK required.

## Tuning the transition

At the top of `FoldveilGalleryScreen.kt`:

- `VEIL_DURATION_MS` — how long the sweep takes (ms)
- `MAX_SWEEP_DEGREES` — how far the cover rotates open
- `MIN_OPACITY_AT_END` — how translucent the cover gets by the end
  of the sweep (lower = more see-through)
- `VeilEasing` — the easing curve (currently eases out, matching
  "heavy start, light finish")

